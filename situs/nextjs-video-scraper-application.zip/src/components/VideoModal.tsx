"use client";

import React, { useEffect, useState, useCallback } from "react";
import {
  X,
  ChevronLeft,
  ChevronRight,
  Download,
  Calendar,
  Clock,
  Layers,
  Tag,
  Bookmark,
  BookmarkCheck,
  Share2,
  Copy,
  Check,
  ExternalLink,
  ShieldCheck,
  Play,
  Loader2,
  AlertCircle,
  Terminal,
  Maximize2,
} from "lucide-react";
import { VideoDetail, VideoItem } from "@/lib/scraper";
import HlsPlayer from "./HlsPlayer";

interface VideoModalProps {
  slugOrUrl: string;
  onClose: () => void;
  onNavigateVideo: (slugOrUrl: string) => void;
  allVideosList?: VideoItem[];
  currentIndex?: number;
}

export default function VideoModal({
  slugOrUrl,
  onClose,
  onNavigateVideo,
  allVideosList = [],
  currentIndex = -1,
}: VideoModalProps) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [videoData, setVideoData] = useState<VideoDetail | null>(null);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [showFullDesc, setShowFullDesc] = useState(false);

  // Load video detail
  const loadDetail = useCallback(async (target: string) => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/video/detail?url=${encodeURIComponent(target)}`);
      const data = await res.json();
      if (!data.success || !data.video) {
        throw new Error(data.error || "Gagal memuat detail video.");
      }
      setVideoData(data.video);

      // Check bookmark status
      try {
        const bmRes = await fetch("/api/bookmarks");
        const bmData = await bmRes.json();
        if (bmData.success && bmData.items) {
          const found = bmData.items.some(
            (b: any) => b.postId === data.video.id || b.url === data.video.url
          );
          setIsBookmarked(found);
        }
      } catch (e) {
        // ignore
      }
    } catch (err: any) {
      setError(err.message || "Gagal mengambil data video.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (slugOrUrl) {
      loadDetail(slugOrUrl);
    }
  }, [slugOrUrl, loadDetail]);

  // Keyboard navigation: Escape to close, Left/Right arrows for Prev/Next video
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      } else if (e.key === "ArrowLeft") {
        handlePrev();
      } else if (e.key === "ArrowRight") {
        handleNext();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  });

  // Previous and Next video handling
  const handlePrev = () => {
    if (currentIndex > 0 && allVideosList[currentIndex - 1]) {
      onNavigateVideo(allVideosList[currentIndex - 1].url || allVideosList[currentIndex - 1].slug);
    } else if (videoData?.relatedVideos && videoData.relatedVideos.length > 0) {
      const last = videoData.relatedVideos[videoData.relatedVideos.length - 1];
      onNavigateVideo(last.url || last.slug);
    }
  };

  const handleNext = () => {
    if (currentIndex >= 0 && currentIndex < allVideosList.length - 1 && allVideosList[currentIndex + 1]) {
      onNavigateVideo(allVideosList[currentIndex + 1].url || allVideosList[currentIndex + 1].slug);
    } else if (videoData?.relatedVideos && videoData.relatedVideos.length > 0) {
      const nextRel = videoData.relatedVideos[0];
      onNavigateVideo(nextRel.url || nextRel.slug);
    }
  };

  const toggleBookmark = async () => {
    if (!videoData) return;
    try {
      if (isBookmarked) {
        await fetch(`/api/bookmarks?postId=${encodeURIComponent(videoData.id)}`, {
          method: "DELETE",
        });
        setIsBookmarked(false);
      } else {
        await fetch("/api/bookmarks", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            postId: videoData.id,
            title: videoData.title,
            url: videoData.url,
            thumbnail: videoData.thumbnail,
            duration: videoData.duration,
            category: videoData.categories[0] || "Bokep Indo",
          }),
        });
        setIsBookmarked(true);
      }
    } catch (e) {
      console.error("Bookmark toggle failed:", e);
    }
  };

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-2 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-6xl bg-zinc-950 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[96vh] flex flex-col">
        {/* Top Header Bar */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3 border-b border-zinc-800 bg-zinc-900/90 shrink-0">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-zinc-800 text-[11px] font-mono text-zinc-300 border border-zinc-700">
              {videoData?.id ? `ID #${videoData.id}` : "THEATER VIEW"}
            </span>
            {videoData?.playerProvider && (
              <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded bg-zinc-800/80 text-[11px] font-mono text-zinc-400 border border-zinc-700/60">
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                {videoData.playerProvider}
              </span>
            )}
          </div>

          {/* Quick Prev / Next in Header */}
          <div className="flex items-center gap-1 sm:gap-2">
            <button
              onClick={handlePrev}
              className="px-2 sm:px-3 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs rounded-lg border border-zinc-700 transition flex items-center gap-1 cursor-pointer"
              title="Video Sebelumnya (Panah Kiri)"
            >
              <ChevronLeft className="w-4 h-4" />
              <span className="hidden sm:inline">Sebelumnya</span>
            </button>
            <button
              onClick={handleNext}
              className="px-2 sm:px-3 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs rounded-lg border border-zinc-700 transition flex items-center gap-1 cursor-pointer"
              title="Video Selanjutnya (Panah Kanan)"
            >
              <span className="hidden sm:inline">Selanjutnya</span>
              <ChevronRight className="w-4 h-4" />
            </button>

            <button
              onClick={onClose}
              className="p-1.5 ml-2 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-lg transition"
              title="Tutup (Esc)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {loading ? (
            <div className="py-24 flex flex-col items-center justify-center gap-4 text-center">
              <Loader2 className="w-12 h-12 text-zinc-400 animate-spin" />
              <div>
                <p className="text-sm font-medium text-zinc-200">
                  Mendekripsi Player &amp; Membypas CDN Live...
                </p>
                <p className="text-xs text-zinc-500 font-mono mt-1">
                  Extracting m3u8 playlist and resolutions from AVTub
                </p>
              </div>
            </div>
          ) : error ? (
            <div className="py-16 text-center space-y-4">
              <AlertCircle className="w-12 h-12 text-red-400 mx-auto" />
              <div>
                <p className="text-base font-semibold text-zinc-100">{error}</p>
                <p className="text-xs text-zinc-400 mt-1">
                  Konten gagal dimuat atau halaman sedang tidak dapat diakses.
                </p>
              </div>
              <button
                onClick={() => loadDetail(slugOrUrl)}
                className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-xs text-zinc-200 rounded-lg border border-zinc-700"
              >
                Coba Lagi
              </button>
            </div>
          ) : videoData ? (
            <>
              {/* Video Player Section */}
              <div className="relative rounded-xl overflow-hidden bg-black border border-zinc-800 shadow-2xl">
                <HlsPlayer
                  src={videoData.proxiedMasterM3u8 || videoData.masterM3u8 || ""}
                  fallbackEmbedUrl={videoData.embedUrl}
                  poster={videoData.thumbnail}
                  title={videoData.title}
                  streams={videoData.streams}
                />
              </div>

              {/* Navigation Bar under Video: Klik Kiri Kanan Untuk All Video Selanjutnya */}
              <div className="p-3 rounded-xl bg-zinc-900/90 border border-zinc-800 flex items-center justify-between flex-wrap gap-2 text-xs">
                <button
                  onClick={handlePrev}
                  className="px-3.5 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-medium rounded-lg border border-zinc-700 flex items-center gap-2 transition cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Video Sebelumnya</span>
                </button>

                <div className="text-zinc-400 text-center font-mono text-[11px]">
                  <span>Nonton Selanjutnya Sampai Akhir ⚡</span>
                </div>

                <button
                  onClick={handleNext}
                  className="px-3.5 py-2 bg-zinc-100 hover:bg-white text-zinc-950 font-semibold rounded-lg shadow flex items-center gap-2 transition cursor-pointer"
                >
                  <span>Video Selanjutnya</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {/* Video Title and Metadata Bar */}
              <div className="space-y-4">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <h1 className="text-xl sm:text-2xl font-bold text-white leading-tight">
                    {videoData.title}
                  </h1>

                  {/* Actions */}
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={toggleBookmark}
                      className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition flex items-center gap-1.5 cursor-pointer ${
                        isBookmarked
                          ? "bg-zinc-100 text-zinc-950 border-white font-semibold"
                          : "bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border-zinc-800"
                      }`}
                    >
                      {isBookmarked ? (
                        <>
                          <BookmarkCheck className="w-4 h-4" />
                          Tersimpan
                        </>
                      ) : (
                        <>
                          <Bookmark className="w-4 h-4" />
                          Simpan
                        </>
                      )}
                    </button>

                    <button
                      onClick={() => copyToClipboard(videoData.url, "share-url")}
                      className="px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-800 text-xs font-medium transition flex items-center gap-1.5 cursor-pointer"
                    >
                      {copiedKey === "share-url" ? (
                        <>
                          <Check className="w-4 h-4 text-emerald-400" />
                          Link Tersalin
                        </>
                      ) : (
                        <>
                          <Share2 className="w-4 h-4" />
                          Bagi Link
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Metadata Badges */}
                <div className="flex flex-wrap items-center gap-3 text-xs text-zinc-400 pt-1">
                  {videoData.publishDate && (
                    <span className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-zinc-500" />
                      {new Date(videoData.publishDate).toLocaleDateString("id-ID", {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </span>
                  )}
                  <span className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-zinc-500" />
                    {videoData.duration}
                  </span>
                  {videoData.categories.map((cat, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-0.5 bg-zinc-800/80 rounded-md text-zinc-300 border border-zinc-700 text-[11px]"
                    >
                      {cat}
                    </span>
                  ))}
                </div>

                {/* Description Box */}
                {videoData.description && (
                  <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800/80 text-xs text-zinc-300 space-y-2">
                    <div className="font-semibold text-zinc-400 uppercase tracking-wider text-[10px] font-mono">
                      Deskripsi Video
                    </div>
                    <p
                      className={`leading-relaxed text-zinc-300 ${
                        !showFullDesc ? "line-clamp-2" : ""
                      }`}
                    >
                      {videoData.description}
                    </p>
                    {videoData.description.length > 140 && (
                      <button
                        onClick={() => setShowFullDesc(!showFullDesc)}
                        className="text-zinc-400 hover:text-white font-medium text-[11px] underline cursor-pointer"
                      >
                        {showFullDesc ? "Tampilkan lebih sedikit" : "Selengkapnya"}
                      </button>
                    )}
                  </div>
                )}
              </div>

              {/* REAL DOWNLOADER SECTION */}
              <div className="p-5 rounded-xl bg-zinc-900/80 border border-zinc-800 space-y-4">
                <div className="flex items-center justify-between border-b border-zinc-800/80 pb-3">
                  <div className="flex items-center gap-2">
                    <Download className="w-4 h-4 text-zinc-300" />
                    <span className="font-semibold text-sm text-white">
                      Download Video &amp; Direct Links
                    </span>
                  </div>
                  <span className="text-[11px] font-mono text-zinc-400 bg-zinc-800 px-2 py-0.5 rounded border border-zinc-700">
                    Host: {videoData.playerProvider || "CDN"}
                  </span>
                </div>

                {/* Quality options */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {videoData.streams.length > 0 ? (
                    videoData.streams.map((stream, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-lg bg-zinc-950 border border-zinc-800 flex flex-col justify-between gap-2"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-white">
                            {stream.label}
                          </span>
                          {stream.resolution && (
                            <span className="text-[10px] font-mono text-zinc-400 bg-zinc-800 px-1.5 py-0.5 rounded">
                              {stream.resolution}
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-1.5 pt-1">
                          <a
                            href={`/api/download?url=${encodeURIComponent(
                              stream.url
                            )}&filename=${encodeURIComponent(
                              `${videoData.title}-${stream.label}.m3u8`
                            )}&title=${encodeURIComponent(videoData.title)}&id=${videoData.id}&quality=${stream.label}`}
                            className="flex-1 px-2.5 py-1.5 bg-zinc-100 hover:bg-white text-zinc-950 text-[11px] font-semibold rounded text-center transition flex items-center justify-center gap-1"
                            download
                          >
                            <Download className="w-3 h-3" />
                            Download M3U8
                          </a>
                          <button
                            onClick={() => copyToClipboard(stream.url, `dl-${idx}`)}
                            className="p-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded transition"
                            title="Salin Link Stream"
                          >
                            {copiedKey === `dl-${idx}` ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      </div>
                    ))
                  ) : videoData.masterM3u8 ? (
                    <div className="col-span-full p-3 rounded-lg bg-zinc-950 border border-zinc-800 flex items-center justify-between">
                      <div>
                        <span className="text-xs font-bold text-white block">
                          Master HLS Stream (Semua Resolusi)
                        </span>
                        <span className="text-[11px] text-zinc-400 font-mono">
                          Direct CDN Stream URL
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <a
                          href={`/api/download?url=${encodeURIComponent(
                            videoData.masterM3u8
                          )}&filename=${encodeURIComponent(
                            `${videoData.title}-master.m3u8`
                          )}&title=${encodeURIComponent(videoData.title)}&id=${videoData.id}`}
                          className="px-3 py-1.5 bg-zinc-100 hover:bg-white text-zinc-950 text-xs font-semibold rounded transition flex items-center gap-1.5"
                          download
                        >
                          <Download className="w-3.5 h-3.5" />
                          Download File M3U8
                        </a>
                        <button
                          onClick={() =>
                            copyToClipboard(videoData.masterM3u8!, "master-url")
                          }
                          className="p-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded transition"
                          title="Salin Link"
                        >
                          {copiedKey === "master-url" ? (
                            <Check className="w-4 h-4 text-emerald-400" />
                          ) : (
                            <Copy className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    </div>
                  ) : null}
                </div>

                {/* External Savetub link */}
                {videoData.originalDownloadUrl && (
                  <div className="flex items-center justify-between pt-1 text-xs">
                    <span className="text-zinc-400">
                      Link download eksternal resmi (Savetub):
                    </span>
                    <a
                      href={videoData.originalDownloadUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded border border-zinc-700 transition flex items-center gap-1.5"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      Buka di Savetub
                    </a>
                  </div>
                )}

                {/* FFMPEG Command helper */}
                {videoData.masterM3u8 && (
                  <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800 text-[11px] font-mono space-y-1.5">
                    <div className="flex items-center justify-between text-zinc-400">
                      <span className="flex items-center gap-1">
                        <Terminal className="w-3 h-3 text-zinc-500" />
                        Perintah FFMPEG (Download ke MP4 langsung):
                      </span>
                      <button
                        onClick={() =>
                          copyToClipboard(
                            `ffmpeg -i "${videoData.masterM3u8}" -c copy "${videoData.title.replace(/[/\\?%*:|"<>]/g, "-")}.mp4"`,
                            "cmd"
                          )
                        }
                        className="text-zinc-300 hover:text-white flex items-center gap-1 hover:underline cursor-pointer"
                      >
                        {copiedKey === "cmd" ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-400" />
                            Tersalin!
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            Salin Perintah
                          </>
                        )}
                      </button>
                    </div>
                    <div className="p-2 rounded bg-zinc-900 text-zinc-300 break-all select-all">
                      ffmpeg -i &quot;{videoData.masterM3u8}&quot; -c copy &quot;{videoData.title.replace(/[/\\?%*:|"<>]/g, "-")}.mp4&quot;
                    </div>
                  </div>
                )}
              </div>

              {/* Related Videos Section */}
              {videoData.relatedVideos && videoData.relatedVideos.length > 0 && (
                <div className="space-y-3 pt-2">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                      Video Terkait ({videoData.relatedVideos.length})
                    </h3>
                    <span className="text-xs text-zinc-500">
                      Klik untuk menonton langsung
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                    {videoData.relatedVideos.map((item) => (
                      <div
                        key={item.id}
                        onClick={() => onNavigateVideo(item.url || item.slug)}
                        className="group bg-zinc-900 border border-zinc-800 hover:border-zinc-600 rounded-xl overflow-hidden cursor-pointer transition flex flex-col"
                      >
                        <div className="relative aspect-video bg-zinc-950 overflow-hidden">
                          <img
                            src={item.thumbnail}
                            alt={item.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                            loading="lazy"
                          />
                          <span className="absolute bottom-1.5 right-1.5 px-1.5 py-0.5 bg-black/80 text-[10px] font-mono text-zinc-300 rounded">
                            {item.duration}
                          </span>
                          {item.isHD && (
                            <span className="absolute top-1.5 left-1.5 px-1.5 py-0.2 bg-zinc-900/90 text-[9px] font-mono text-zinc-300 rounded border border-zinc-700">
                              HD
                            </span>
                          )}
                        </div>
                        <div className="p-2 flex-1 flex flex-col justify-between">
                          <p className="text-xs text-zinc-200 font-medium line-clamp-2 leading-snug group-hover:text-white">
                            {item.title}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          ) : null}
        </div>
      </div>
    </div>
  );
}
