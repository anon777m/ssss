import { pgTable, text, serial, timestamp, integer, boolean } from "drizzle-orm/pg-core";

export const savedVideos = pgTable("saved_videos", {
  id: serial("id").primaryKey(),
  postId: text("post_id").notNull().unique(),
  title: text("title").notNull(),
  url: text("url").notNull(),
  thumbnail: text("thumbnail"),
  duration: text("duration"),
  category: text("category"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const downloadHistory = pgTable("download_history", {
  id: serial("id").primaryKey(),
  postId: text("post_id"),
  title: text("title").notNull(),
  videoUrl: text("video_url"),
  streamUrl: text("stream_url"),
  quality: text("quality"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const searchLogs = pgTable("search_logs", {
  id: serial("id").primaryKey(),
  query: text("query").notNull(),
  resultsCount: integer("results_count").default(0),
  searchedAt: timestamp("searched_at").defaultNow().notNull(),
});
