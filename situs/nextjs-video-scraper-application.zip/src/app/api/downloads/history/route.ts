import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { downloadHistory } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const items = await db
      .select()
      .from(downloadHistory)
      .orderBy(desc(downloadHistory.createdAt))
      .limit(50);

    return NextResponse.json({ success: true, items });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { postId, title, videoUrl, streamUrl, quality } = body;

    const inserted = await db
      .insert(downloadHistory)
      .values({
        postId: postId ? String(postId) : null,
        title: title || "Video Download",
        videoUrl: videoUrl || null,
        streamUrl: streamUrl || null,
        quality: quality || "1080p",
      })
      .returning();

    return NextResponse.json({ success: true, item: inserted[0] });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}
