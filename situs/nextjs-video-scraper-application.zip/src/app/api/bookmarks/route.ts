import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { savedVideos } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const items = await db
      .select()
      .from(savedVideos)
      .orderBy(desc(savedVideos.createdAt));
    return NextResponse.json({ success: true, items });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { postId, title, url, thumbnail, duration, category } = body;

    if (!postId || !title || !url) {
      return NextResponse.json(
        { success: false, error: "Missing required fields" },
        { status: 400 }
      );
    }

    // Insert or ignore if duplicate
    const existing = await db
      .select()
      .from(savedVideos)
      .where(eq(savedVideos.postId, String(postId)));

    if (existing.length > 0) {
      return NextResponse.json({
        success: true,
        message: "Already saved",
        item: existing[0],
      });
    }

    const inserted = await db
      .insert(savedVideos)
      .values({
        postId: String(postId),
        title,
        url,
        thumbnail: thumbnail || null,
        duration: duration || null,
        category: category || null,
      })
      .returning();

    return NextResponse.json({ success: true, item: inserted[0] });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const postId = searchParams.get("postId");

    if (!postId) {
      return NextResponse.json(
        { success: false, error: "Missing postId" },
        { status: 400 }
      );
    }

    await db.delete(savedVideos).where(eq(savedVideos.postId, String(postId)));

    return NextResponse.json({ success: true, message: "Bookmark removed" });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}
